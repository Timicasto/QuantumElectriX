package timicasto.quantumelectrix.api;

import net.minecraft.item.ItemStack;

import java.util.*;

public class LargeAssemblyRecipe {
    /*
    List<ItemStack> batteryCaseInput = new ArrayList<ItemStack>();
    
    public void newRecipe() {
        batteryCaseInput.add(new ItemStack());
        batteryCaseInput.add(in2);
        batteryCaseInput.add(in3);
        batteryCaseInput.add(in4);
        batteryCaseInput.add(in5);
        batteryCaseInput.add(in6);
        batteryCaseInput.add(in7);
        batteryCaseInput.add(in8);
        batteryCaseInput.add(in9);
        batteryCaseInput.add(in10);
        batteryCaseInput.add(in11);
        batteryCaseInput.add(in12);
        batteryCaseInput.add(in13);
        batteryCaseInput.add(in14);
        batteryCaseInput.add(in15);
        batteryCaseInput.add(in16);
        batteryCaseInput.add(in17);
        batteryCaseInput.add(in18);
        batteryCaseInput.add(in19);
        batteryCaseInput.add(in20);
        batteryCaseInput.add(in21);
        batteryCaseInput.add(in22);
        batteryCaseInput.add(in23);
        batteryCaseInput.add(in24);
        batteryCaseInput.add(in25);
        batteryCaseInput.add(in26);
        batteryCaseInput.add(in27);
        batteryCaseInput.add(in28);
        batteryCaseInput.add(in29);
        batteryCaseInput.add(in30);
        batteryCaseInput.add(in31);
        batteryCaseInput.add(in32);
        batteryCaseInput.add(in33);
        batteryCaseInput.add(in34);
        batteryCaseInput.add(in35);
        batteryCaseInput.add(in36);
        batteryCaseInput.add(in37);
        batteryCaseInput.add(in38);
        batteryCaseInput.add(in39);
        batteryCaseInput.add(in40);
        batteryCaseInput.add(in41);
        batteryCaseInput.add(in42);
        batteryCaseInput.add(in43);
        batteryCaseInput.add(in44);
        batteryCaseInput.add(in45);
        batteryCaseInput.add(in46);
        batteryCaseInput.add(in47);
        batteryCaseInput.add(in48);
        batteryCaseInput.add(in49);
        batteryCaseInput.add(in50);
    }
}
*/
}