package timicasto.quantumelectrix.api.ints;

import timicasto.quantumelectrix.api.TransmittionType;

public interface IWire {
    TransmittionType getTransmissionType();
}
