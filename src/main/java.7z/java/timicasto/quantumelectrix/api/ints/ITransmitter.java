package timicasto.quantumelectrix.api.ints;

import timicasto.quantumelectrix.api.TransmittionType;

public interface ITransmitter {
    TransmittionType getTransmissionType();
}
