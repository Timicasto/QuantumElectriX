package timicasto.quantumelectrix;

public interface INetData {
    String getNeededInfo();
    String getStoredInfo();
    String getFlowInfo();
}
